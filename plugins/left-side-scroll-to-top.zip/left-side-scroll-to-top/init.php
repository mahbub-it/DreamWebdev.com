<?php 
/**
* Plugin Name: Left Side Scroll to Top
* Plugin URI: http://cg-webdev-tech.com/projects/plugins/left-side-scroll-to-top.zip
* Author: Mahbub
* Author URI: http://mahbub.cg-webdev-tech.com
* Description: Left Side Scroll to Top
* Version: 1.0
*/
defined('ABSPATH') or die('directory browsing is disabled');

add_action('wp_footer', 'some_codes');
function some_codes(){
	?>
	<div class="scroll-to-top">
		<a href="#"><i class="fa fa-angle-up"></i></a>
	</div>
	<?php
}

add_action('wp_enqueue_scripts', 'new_theme_styles');

	function new_theme_styles(){
		wp_enqueue_style('locate-font-awesome', PLUGINS_URL('css/all.min.css', __FILE__));
		wp_enqueue_style('locate-css-style', PLUGINS_URL('css/custom.css', __FILE__));
		wp_enqueue_script('locate-custom-js', PLUGINS_URL('scripts/custom.js', __FILE__), array('jquery'), '', false);

}
