=== Left Side Scroll To Top ===
Contributors: bdsmrahman
Donate link: http://cg-webdev-tech.com/projects/plugins/left-side-scroll-to-top.zip
Tags: scrolling, mahbub, scroll to top, right side scrolling, simple scrolling, smooth scrolling
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 4.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Scroll to top is a WordPress plugin. It can easy to use for smooth scrolling webpage from bottom or center to top. 

== Description ==
This is a simple scrolling page attractive usable plugin.  Scroll to the Top is a flexible, open-source built in WordPress. 
When the position of your page moves away from the top, it can easily help you get to the top position.

After install plugin, it will show on your page at left of bottom side. 

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/left-side-scroll-to-top` directory, or install the plugin through the 
WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Plugin Name screen to configure the plugin

== Frequently Asked Questions ==

An answer to that question.

= What about the scrolling button after click? =

The page scrolling smoothly to top area.

== Screenshots ==

1. First screen shot (Screenshot_1.jpg) is, after setup the 'Left Side Scroll To Top' plugin. The screen shot location
is `/tags/4.3/Screenshot_1.jpg`.

2. '/tags/4.3/Screenshot_2.jpg' this is the second screen shot location. Here you will see the result after activate plugin on any
WordPress pages. Red arrow marked is click object.

== Changelog ==

= 1.0 =
* 1.0


